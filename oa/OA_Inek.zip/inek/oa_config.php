<?php
	/* Created by EBSCO LSE (Seong hoon). Please contact skim2@ebsco.com if any question */
	$oa_connectionid = "282fa22e-bd1b-46a8-8cb2-109840782a51";
	$oa_endpoint = "https://login.openathens.net/api/v1/apacebsco.com/organisation/71359635/local-auth/session";
	$oa_apikey = "KE7ZIJSnany0WHA1OwBNzFevPohWo0sxHc7fiAEi";
    
?>
